

class Cat:

# class attribute
	attrib = "mammal" #This is a class variarable
	
	crawl1 = "crawling"
# Instance attribute
	def __init__(self, name): 

		self.name = name # An instance variable

	def speak(self):

		print ("My Cats  is  {}".format(self.name), "and i am a {}".format(cat1.__class__.attrib))

	def movement(self):

		print("My {}".format(cat1.name), "is a {}".format(cat1.__class__.attrib), "and it loves {}".format(cat1.__class__.crawl1), "on grass")


# Driver code
# Object instantiation - You can create as many objects from the class as possible.
cat1 = Cat("Tim")
#cat2 = Cat("Ruth")
#cat3 = Cat ("Kelly")

# Accessing class attributes
#print ("My Cats  is a {}".format(cat1.__class__.attrib),"and can {}".format(cat1.__class__.attrib1))

# Accessing instance attributes
print ("My Cats name is {}".format(cat1.name))
#print ("My Cats name is {}".format(cat2.name))
#print ("My Cats name is {}".format(cat3.name))

#Accessing the SPEAK function using the object.
cat1.speak()

cat1.movement()

class Dog(Cat):

	@Cat

	def dog_acts(self):
		print ("Dogs are friendly pets too")



	