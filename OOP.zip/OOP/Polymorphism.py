
class Bird():

	def opener(self):

		print("All birds are equal :-)")


class Sparrow(Bird):

	def fly(self):

		print("Sparrows can Fly")

class Chicken(Bird):

	def fly(self):

		print(" Chickens cannot fly")


#Method overiding in subclasses.
#all child classess can access the parent class methods.

ndege = Bird()

ndegekuku = Chicken()

ndegesparrow = Sparrow()


ndegesparrow.fly()

ndegesparrow.opener()


ndegekuku.opener()
ndegekuku.fly()

