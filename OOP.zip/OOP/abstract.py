from abc import ABC, abstractmethod


class Enterprise(ABC):

	@abstractmethod #USED TO CREATE AN ABSTRACT IN A CLASS 
	#WHEREBY THE FUNCTIONS DECLARED IN A CLASS MUST APPLY TO ALL THE 
	 #SUBCLASSES I.E def calcYearExpenses()

	def calcYearExpenses():
		pass


class TechShop (Enterprise):

	def calcYearExpenses(self):

		print("TechShop")


obj = TechShop()

obj.calcYearExpenses()