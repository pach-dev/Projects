class person():

	def __init__(self, name, id_number):
		
		self.name = name
		self.id_number = id_number



	def details(self):

		print (self.name)
		print (self.id_number)


		

	def displayinfo(self):
		print ("My name is: {}".format(self.name))
		print ("My ID number is: {}".format(self.id_number))
		




class employee(person):

	def __init__(self, name, id_number, employee_id, status):

		self.employee_id = employee_id

		self.status = status


		person.__init__(self,name, id_number)



	def displayinfo(self):

		print ("My name is: {}".format(self.name))
		print ("My ID number is: {}".format(self.id_number))
		print ("My Employee ID is: {}".format(self.employee_id))
		print ("My Job status is: {}".format(self.status))



class Student(person):


	def __init__(self, name, id_number, studentid, course):

		self.studentid = studentid
		self.course = course


		person.__init__(self,name, id_number)

	def displayinfo(self):

		print ("My name is: {}".format(self.name))
		print ("My ID number is: {}".format(self.id_number))
		print ("My Student ID is: {}".format(self.studentid))
		print ("My School course is: {}".format(self.course))



class IT_Specialist(person):


		


a = employee("rones", 27344183, 1003261, "IT Dept Head")
b = Student("peter", 27354178, "KD100326", "Engineering")


b.details()
b.displayinfo()
